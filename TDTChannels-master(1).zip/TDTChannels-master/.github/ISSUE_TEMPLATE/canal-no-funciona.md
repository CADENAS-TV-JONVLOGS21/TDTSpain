---
name: Canal no funciona
about: Si deseas informar sobre un canal que no funcione o si tienes sus datos actualizados
title: 'Canal no funciona: NOMBRE'
labels: canal-no-funciona
assignees: ''

---

<En caso de saberlo indica debajo de esta linea la URL de la web de origen del canal><REQUERIDO>

<En caso de saberlo indica debajo de esta linea la URL de la emision><REQUERIDO>


<Indica debajo de esta linea cualquier otra informacion relativa a esta propuesta>
