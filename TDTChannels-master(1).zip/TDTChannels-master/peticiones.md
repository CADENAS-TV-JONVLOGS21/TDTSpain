Si deseas hacer una petición de inclusión de canal al proyecto, puedes hacerlo de dos formas.

[Vía Pull Request](https://github.com/LaQuay/TDTChannels/edit/master/CONTRIBUTING.md)

[Vía Formulario](https://tdtchannels.com/peticion)

# Requisitos de inclusión
Las emisiones deben cumplir los siguientes puntos:
- La fuente debe ser la página oficial de la emisión.
- El acceso debe ser directo, no se aceptarán emisiones previo registro / pago.
- Deben ser visibles en España. Es el objetivo del proyecto. La mayoría del tiempo deben ser visibles en territorio español.

## Vía Pull Request
En [este documento](https://github.com/LaQuay/TDTChannels/edit/master/CONTRIBUTING.md) encontrarás la información de como realizar la Pull Request

## Vía Formulario
En [este formulario](https://tdtchannels.com/peticion) podrás realizar la petición.
