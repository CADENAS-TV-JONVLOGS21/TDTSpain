#### Lead
- Marc [@LaQuay](https://github.com/LaQuay)

#### Team
- Antonio [@atnbueno](https://github.com/atnbueno)
- HelmerLuzo [@HelmerLuzo](https://github.com/HelmerLuzo)
- José Antonio [@nomentero](https://github.com/Nomenteros)
- Playz [@playzzz](https://github.com/playzzz)

#### Contributions (in alphabetical order)
- Adrian [@adrianpaniagualeon](https://github.com/adrianpaniagualeon)
- Aitor [@aitorillo](https://github.com/aitorillo)
- Alex Gabriel [@97carmine](https://github.com/97carmine)
- Angel [@PIC16f841](https://github.com/PIC16f841)
- Berto [@Berto9050](https://github.com/Berto9050)
- CaRLymx [@carlymx](https://github.com/carlymx)
- Carlos [@profesorasix](https://github.com/profesorasix)
- Carratraka [@carratraka](https://github.com/carratraka)
- David [@david-cp](https://github.com/David-cp)
- Jacobo [@poborp](https://github.com/poborp)
- Jorge [@jaguaza](https://github.com/jaguaza)
- Juan [@okelet](https://github.com/okelet)
- Miguel A. [@MiguelAngel2345](https://github.com/MiguelAngel2345)
- Ricardo [@RicardoVelaC](https://github.com/RicardoVelaC)
- Valentin [@vk496](https://github.com/vk496)

Si haces una *Pull Request*, no olvides incluirte en este fichero. 
